----McTabs jQuery version----

1. Steps to make the demos using the jquery-tabs.js:
	1.1: Download the McTabs in plain JavaScript version
	1.2: Delete the javascript-tabs.js in the package
	1.3: Add this jquery-tabs.js file to the mctabs folder
	1.4: Open the demo HTML files with Notepad, 
	     replace: <script src="javascript-tabs.js" type="text/javascript"></script>
	     with:    <script src="jquery-tabs.js" type="text/javascript"></script>
	1.5: Add the jQuery library script before the script link added in Step 1.4 (Make sure the jQuery to be the first among all other script links)
	     For example: <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	     Note: You can use any version of the jquery.min.js.


	Done! You can test the demo pages now. When you are comfortable with it, copy the related files and codes into your own application.


2. FAQ:    Should I use your plain javascript version, or the jQuery version?

   Answer: If your application has already used the jQuery, you can consider using this jQuery version as it is about 1KB smaller 
	   than the size of the javascript-tabs.js. There is no other benefit as both versions are exactly the same in 
	   functionality, usage and performance. 

	   Most users are using the plain javascript version even if their application has linked the jQuery library. 