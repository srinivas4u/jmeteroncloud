#!"C:\xampp\perl\bin\perl.exe"

use CGI qw/:standard/;
use File::Basename;
use Date::Parse;
use List::Util qw{sum min max};
use JSON;
require Exporter;
$cgi = new CGI;

print header,start_html($dirpath);
	
print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"';
print '    "http://www.w3.org/TR/html4/loose.dtd">';
print '<html>';
print '<head>';
print '<meta name="author" content="Srinviasan Palanimuthu">';
print '<link href="xampp.css" rel="stylesheet" type="text/css">';
print '<title>Jmeter on Perl V.0.01 Book (JoC)</title>';
print '</head>';

print '<body>';

print "<br><h1>Jmeter on Perl V.0.01 Book (JoC)</h1>";

print "<p>Jmeter Internal Framework</p>"; 
print "<h1>Analysis Summary Report </h1>";
sub Audit_Data
{
for $key ( $cgi->param() ) {
    $ProjectNam = $input{$key} = $cgi->param($key);
	$ProjectNam;
}

chomp($ProjectNam);

$LOGFILE = "./Jmeter/PayPal/Results/$ProjectNam";
open(LOGFILE) or die("Could not open log file.");
$out="./Jmeter/PayPal/Results/$ProjectNam";
chomp($out);
unlink("./Jmeter/PayPal/Results/Results.txt");
open (ES,">>./Jmeter/PayPal/Results/Results.txt");
#open (ES1,">>C:/Perl64/bin/OpenStaReport/Results.xls");

@line =<LOGFILE>;
chomp(@line);
my $y = scalar(@line);


for ($i=1;$i<=$y-1; $i++)
{
$line[$i] =~s/, number/ number/gi;
$line[$i] =~s/"//gi;

($timeStamp, $elapsed, $label, $responseCode, $responseMessage,$threadName,$dataType,
         $success, $bytes, $grpThreads, $allThreads,$URL, $Latency, $IdleTime) = split(',',$line[$i]);
			 		 #$elapsed = $elapsed / 1000 ;
					 
		$elapsed++;
		if  (grep !/null/,$URL)
		{
				#$label = substr($label,0,12);
			$label =~s/,//gi;
			$label =~s/"//gi;
			$label =~s/-//gi;
				$label =~s/ExternalUnAuthu_//gi;
			$label = substr($label,0, 20);
					$inttime = substr($line[1],0, 10);
						$Ftime = 	substr($line[$i],0, 10);
					$Ltime =  substr($line[1],0, 10);
					
   ($st) =&epoch_to_time($inttime);
		$endtime = substr($line[$y-1],0, 10);
   ($et) =&epoch_to_time($endtime);
			 $id = str2time($st) - str2time($et);
			 $id =~s/-//gi;
	  
	################Seconds to hrs min sec convertion###################################
	my $seconds = $id;
		 my $hrs = int( $seconds / (60*60) );
			 my $min = int( ($seconds - $hrs*60*60) / (60) );
				 my $sec = int( $seconds - ($hrs*60*60) - ($min*60) );
	 $id2hrs = $hrs.":".$min.":".$sec;
		 
	################EpochTime Conversion ############################################
	
	

	sub epoch_to_time
	{
		my $myepoch = shift;
		 # or any other epoch timestamp 
		my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
			my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
		my ($sec, $min, $hour, $day,$month,$year) = (localtime($myepoch))[0,1,2,3,4,5]; 
			return		$timevalue =  "".$hour.":".$min.":".$sec;
	}
	
	sub epoch_to_date
	{
		my $myepochdate = shift;
		 # or any other epoch timestamp 
		my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
			my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
		my ($sec, $min, $hour, $day,$month,$year) = (localtime($myepochdate))[0,1,2,3,4,5]; 
			return $datevalue = $months[$month]." ".$day." ".($year+1900);
	}
	    ($datevalue) =&epoch_to_date($inttime); 
				($itimeStamp) = &epoch_to_time($inttime);
						($timevalue) =&epoch_to_time($Ftime); 
					$iduration = str2time($itimeStamp) - str2time($timevalue);	
											$iduration =~s/-//gi;
			my $seconds = $iduration;
		 my $hrs = int( $seconds / (60*60) );
			 my $min = int( ($seconds - $hrs*60*60) / (60) );
				 my $sec = int( $seconds - ($hrs*60*60) - ($min*60) );
	 $durationv = $hrs.":".$min.":".$sec;
	
 	# Debug OutPut
	print ES "$label,$itimeStamp,$datevalue,$timevalue,$iduration,$durationv,$elapsed,$responseCode,$threadName,$dataType,$success,$bytes,$grpThreads,$allThreads,$URL,$Latency,$IdleTime,$responseCode $responseMessage\n";
	
			  push @tmp_threads, $allThreads;
			   push @tmp_elapsed, $elapsed;
			   $z++; 
		 
	}
  }
 
  close(ES);
    close(LOGFILE);

	###########################Before the Function#######################################################################
# To Request / URL without null
$urltot = $z++;

# Number of User Calculation

@tmp_threads = sort  { $a <=> $b } @tmp_threads;


@tmp_elapsed = sort  { $a <=> $b } @tmp_elapsed;

 $minHttpReq = $tmp_elapsed[0];
 $maxHttpReq = $tmp_elapsed[1];
	

###########################Average Response Time##########################################################
	#---TPS---Calculation
	 $tps =(($urltot) / $id);
	
	#-Number of Threads-- Calculation
	
	$nofth = $urltot;
	
	
##################################### SUMMARY OUTPUT ####################################################
# print "Date : ".$datevalue."\n";
# print "Duration : ".$id2hrs."\n" ;
# print "Duration in Seconds : ".$id."\n" ;
# print "Start Time : ".$st."\n";
# print "End Time : ".$et."\n";
# print "Average Throughput (TPS) : ".$tps."\n";
#
############################################## HTML Templates #############################################
	# my %jmeter = %{ (shift) };
	my $RS = sprintf "%.3f",(eval join '+', @tmp_elapsed)/$nofth;
    my $TH=$nofth;
    my $TR=$nofth + $TE;
	my $TEP=sprintf "%.3f",($TE/$TR)*100;
    my $THP=sprintf "%.3f",($TH/$TR)*100;
    #  (/1000) set the value in sec.
   
###############Template###################

print  <<START;

<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#f87820>
<td class=tabhead><img src=img/blank.gif width=450 height=6><br><b>Analysis Summary</b></td>
<td class=tabhead><img src=img/blank.gif width=450 height=6><br><b>Duration: $id in Seconds</b></td>
</tr>    
</table>  
<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#ffffff>  
<tr valign=center>
		<td class=tabval><img src=img/blank.gif width=900 height=6>
		<tr><td class=tabval><b>Start Time: $st</b></td></tr>
		<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>
		<tr><td class=tabval><b>End Time: $et</b></td></tr>
		<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>
		<tr><td class=tabval><b>Date: $datevalue</b></td></tr>
		<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>
	</tr></td>	
</table>  
   <table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#f87820>
<td class=tabhead><img src=img/blank.gif width=900 height=6><br><b>&nbsp; Statistics Summary&nbsp;</b></td>
</tr>    
</table>  
<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#ffffff>  
<tr valign=center>
		<td class=tabval><img src=img/blank.gif width=900 height=6>
		<tr><td class=tabval><b>Number of Threads (users): $tmp_threads[-1]</b></td></tr>
		<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>
		<tr><td class=tabval><b>Total Request: $TR</b></td></tr>
		<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>
		<tr><td class=tabval><b>Http request: $TH  ($THP%)</b></td></tr>
		<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>
		<tr><td class=tabval><b>Jmeter Error : $TE  ($TEP%)</b></td></tr>
		<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>
	</tr></td>	
</table>  
<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#f87820>
<td class=tabhead><img src=img/blank.gif width=900 height=6><br><b>&nbsp; Transaction Summary&nbsp;</b></td>
</tr> 
</table>  
<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#ffffff>  
<tr valign=center>
        <td align=center class=tabval  width="180"><b>Transaction Name</b></td>
		<td align=center class=tabval  width="180"><b>Maximum</b></td>
		<td align=center class=tabval  width="180"><b>Minimum</b></td>
		<td align=center class=tabval  width="180"><b>Average</b></td>
		<td align=center class=tabval  width="180"><b>Number of Samplers</b></td>	
<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>		
		</tr></td>
		</table>
<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#ffffff> 
<tr valign=center>	   
START
$DATA = "./Jmeter/PayPal/Results/Results.txt";
open(DATA) or die("Could not open log file.");
while (<DATA>) {
    chomp;
	
	my($label,$itimeStamp,$datevalue,$timevalue,$iduration,$durationv,$elapsed,$responseCode,$threadName,$dataType,$success,$bytes,$grpThreads,$allThreads,$URL,$Latency,$IdleTime,$responseMessage,$responseFailed) = split /,/;
		               
             push @{ $data{$label} }, $elapsed;					 # store values as HoA elapsed time   $jmeter{$responseCode}++;
					push @{ $code{$responseMessage} }, $responseCode;
				 #push @{ $data{$label} }, $IdleTime;	
				 chomp($label);
				 chomp($elapsed);
	
	}
for my $label (sort keys %data) {

   #print "<tr class=\"tabledata_lightrow\"><td headers=\"LraTransaction Name\"><b>$label</b></td>" . summarise($data{$label});
	print  "<tr><td class=tabval  width=\"180\"><b>$label</b>". summarise($data{$label})."</td>";
	print 	"<tr valign=bottom><td bgcolor=#ffffff background=\'img/strichel.gif\' colspan=6><img src=img/blank.gif width=1 height=1></td>";
	
	}
sub summarise{
	my $arr = shift;

	return "<td align=center class=tabval  width=\"180\">".(sprintf "%.3f",max( @$arr ))."</td>"
		. 	"<td align=center class=tabval  width=\"180\">".(sprintf "%.3f",min( @$arr ))."</td>"
			#. sum( @$arr ) 
				.	"<td align=center class=tabval  width=\"180\">".(sprintf "%.3f",(sum(@$arr)/scalar@$arr))."</td>"
					.	"<td align=center class=tabval  width=\"180\">".scalar@$arr."</td>"
					."</tr>";
						print 	"<tr valign=bottom><td bgcolor=#ffffff background=\'img/strichel.gif\' colspan=6><img src=img/blank.gif width=1 height=1></td>";
}
print  <<START;
	</tr></td>	
</table> 
<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#f87820>
<td class=tabhead><img src=img/blank.gif width=900 height=6><br><b>&nbsp; HTTP Response Summary&nbsp;</b></td>
</tr> 
</table>
	</table>
	<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#ffffff>  
<tr valign=center>
        <td class=tabval  width="300"><b>HTTP Responses</b></td>
		<td align=center class=tabval  width="300"><b>Total</b></td>
		<td align=center class=tabval  width="300"><b>Percentage</b></td>		
<tr valign=bottom><td bgcolor=#ffffff background='img/strichel.gif' colspan=6><img src=img/blank.gif width=1 height=1></td>		
		</tr></td>
		</table>
<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#ffffff> 
<tr valign=center>	
START
 for my $responseMessage (sort keys %code) 
	
 {

	print  "<tr><td class=tabval  width=\"300\"><b>http_$responseMessage</b>".codesummarise($code{$responseMessage})."</td>";
	print 	"<tr valign=bottom><td bgcolor=#ffffff background=\'img/strichel.gif\' colspan=6><img src=img/blank.gif width=1 height=1></td>";
    $TE = codesummarise($code{$responseMessage});
		
	 }
 sub codesummarise{
	 my $arr = shift;

	 return 		"<td align=center class=tabval  width=\"300\">".scalar@$arr ."</td>"
				."<td align=center class=tabval  width=\"300\">". scalar@$arr . "</td>"
				 ."</tr>";
			 print 	"<tr valign=bottom><td bgcolor=#ffffff background=\'img/strichel.gif\' colspan=6><img src=img/blank.gif width=1 height=1></td>";
 } 
$DATA1 = "./Jmeter/PayPal/Results/Results.txt";
open(DATA1) or die("Could not open log file.");	  
print  <<START;	
	</tr></td>	
</table>


<table border=0 cellpadding=0 cellspacing=0>
<tr bgcolor=#f87820>
<td class=tabhead><img src=img/blank.gif width=900 height=6><br><b>&nbsp; Response Summary Graph&nbsp;</b></td>
</tr> 
</table>
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript">
      google.load('visualization', '1', {'packages': ['corechart']});
google.setOnLoadCallback(drawChart);

function drawChart() {
    var data = new google.visualization.DataTable();
    data.addColumn('string', 'Time');
    data.addColumn('number', 'elapsed Time');
    data.addColumn('number', 'bytes');
						data.addRows([
START

while (<DATA1>) {
    chomp;
	
	my($label,$itimeStamp,$datevalue,$timevalue,$iduration,$durationv,$elapsed,$responseCode,$threadName,$dataType,$success,$bytes,$grpThreads,$allThreads,$URL,$Latency,$IdleTime,$responseMessage,$responseFailed) = split /,/;
		               
             push @{ $data{$label} }, $elapsed;					 # store values as HoA elapsed time   $jmeter{$responseCode}++;
					push @{ $code{$responseMessage} }, $responseCode;
				 #push @{ $data{$label} }, $IdleTime;	
				 chomp($label);
				 chomp($elapsed);
print "['$durationv',$allThreads,$bytes,],\n";				 
		
	}
print <<START;
 ]);

    var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
    chart.draw(data, {
        width: 900,
        height: 400,
        series: {
            0: {
                targetAxisIndex: 0
            },
            1: {
                targetAxisIndex: 1
            }
        },
        vAxes: {
            0: {
                label: 'Y1'
            },
            1: {
                label: 'Y2'
            }
        }
    });
}
    </script>
   <div id="chart_div" style="width: 900; height: 600px;"></div>
   </tr></td>	
</table>
</body></html>
START
close(DATA1);
}
 
&Audit_Data;







