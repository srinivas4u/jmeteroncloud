#!/usr/bin/perl
use Date::Parse;
use List::Util qw{sum min max};
require Exporter;
#&HttpStat_Data;
# Collecting Datas From Audit log For Time Consuming label`s
sub Audit_Data
{

$LOGFILE = "C:\\Perl64\\bin\\jmReport\\AggregateReport5.jtl";
open(LOGFILE) or die("Could not open log file.");
print "Enter the name/version of Report:";
$out=<stdin>;
chomp($out);
unlink("C:/Perl64/bin/JmeterReports/Results.txt");
open (OUTRES,">>C:/Perl64/bin/JmeterReports/Results.txt");
#open (OUTRES1,">>C:/Perl64/bin/OpenStaReport/Results.xls");

##Temporary Data structures
my %script_stats;
my %httpURL_stats;
my %httpLabel_stats;
my %thread_stats_group;

@line =<LOGFILE>;
chomp(@line);
$y = scalar(@line);


for ($i=1;$i<=$y-1; $i++)
{
$line[$i] =~s/, number/ number/gi;
$line[$i] =~s/"//gi;

($timeStamp, $elapsed, $label, $responseCode, $responseMessage,$threadName,$dataType,
         $success, $bytes, $grpThreads, $allThreads,$URL, $Latency, $IdleTime) = split(',',$line[$i]);
			 		 $elapsed = $elapsed / 1000 ;
		$elapsed++;
		if  (grep !/null/,$URL)
		{
				#$label = substr($label,0,12);
			$label =~s/,//gi;
			$label =~s/"//gi;
			$label =~s/-//gi;
			
					$inttime = substr($line[1],0, 10);
						$Ftime = 	substr($line[$i],0, 10);
					$Ltime =  substr($line[1],0, 10);
					
   ($st) =&epoch_to_time($inttime);
		$endtime = substr($line[$y-1],0, 10);
   ($et) =&epoch_to_time($endtime);
			 $id = str2time($st) - str2time($et);
			 $id =~s/-//gi;
	  
	################Seconds to hrs min sec convertion###################################
	my $seconds = $id;
		 my $hrs = int( $seconds / (60*60) );
			 my $min = int( ($seconds - $hrs*60*60) / (60) );
				 my $sec = int( $seconds - ($hrs*60*60) - ($min*60) );
	 $id2hrs = $hrs.":".$min.":".$sec;
		 
	################EpochTime Conversion ############################################
	
	

	sub epoch_to_time
	{
		my $myepoch = shift;
		 # or any other epoch timestamp 
		my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
			my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
		my ($sec, $min, $hour, $day,$month,$year) = (localtime($myepoch))[0,1,2,3,4,5]; 
			return		$timevalue =  "".$hour.":".$min.":".$sec;
	}
	
	sub epoch_to_date
	{
		my $myepochdate = shift;
		 # or any other epoch timestamp 
		my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
			my @months = ("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");
		my ($sec, $min, $hour, $day,$month,$year) = (localtime($myepochdate))[0,1,2,3,4,5]; 
			return $datevalue = $months[$month]." ".$day." ".($year+1900);
	}
	    ($datevalue) =&epoch_to_date($inttime); 
				($itimeStamp) = &epoch_to_time($inttime);
						($timevalue) =&epoch_to_time($Ftime); 
					$iduration = str2time($itimeStamp) - str2time($timevalue);	
											$iduration =~s/-//gi;
			my $seconds = $iduration;
		 my $hrs = int( $seconds / (60*60) );
			 my $min = int( ($seconds - $hrs*60*60) / (60) );
				 my $sec = int( $seconds - ($hrs*60*60) - ($min*60) );
	 $durationv = $hrs.":".$min.":".$sec;
	
 	# Debug OutPut
	print OUTRES "$label,$itimeStamp,$datevalue,$timevalue,$iduration,$durationv,$elapsed,$responseCode,$threadName,$dataType,$success,$bytes,$grpThreads,$allThreads,$URL,$Latency,$IdleTime,$responseCode $responseMessage\n";
	
			  push @tmp_threads, $allThreads;
			   push @tmp_elapsed, $elapsed;
			   $z++; 
		 print $z++;
	}
	
  }
  
  close(OUTRES);
    close(LOGFILE);
	
}
&Audit_Data;


#######################################Http Error Code####################################################



####################################Response Data#########################################################

my %data;
my %bytes;
my %resCode;
# To Request / URL without null
$urltot = $z++;

# Number of User Calculation

@tmp_threads = sort  { $a <=> $b } @tmp_threads;


@tmp_elapsed = sort  { $a <=> $b } @tmp_elapsed;

	$minHttpReq = $tmp_elapsed[0];
	$maxHttpReq = $tmp_elapsed[1];
	

###########################Average Response Time##########################################################
	#---TPS---Calculation
	$tps =(($urltot) / $id);
	
	#-Number of Threads-- Calculation
	
	$nofth = $urltot;
	
##################################### SUMMARY OUTPUT ####################################################
# print "Date : ".$datevalue."\n";
# print "Duration : ".$id2hrs."\n" ;
# print "Duration in Seconds : ".$id."\n" ;
# print "Start Time : ".$st."\n";
# print "End Time : ".$et."\n";
# print "Average Throughput (TPS) : ".$tps."\n";

############################################## HTML Templates #############################################
	# my %jmeter = %{ (shift) };
	my $RS = sprintf "%.3f",(eval join '+', @tmp_elapsed)/$nofth;
    my $TH=$nofth;
    my $TR=$nofth + $TE;
	my $TEP=sprintf "%.3f",($TE/$TR)*100;
    my $THP=sprintf "%.3f",($TH/$TR)*100;
    #  (/1000) set the value in sec.
   

open (OUTR,">C:\\Perl64\\bin\\JmeterReports\\$out.html");

###############Template###################

print OUTR <<START;
<html>
<link href="C:/Perl64/bin/OpenStaReport/Template/Properties.css" rel="stylesheet" media="screen">
<link href="C:/Perl64/bin/OpenStaReport/Template/adv_properties.css" rel="stylesheet" media="screen">
<head>
<title>Analysis Summary Report</title>
<META HTTP-EQUIV="Expires" CONTENT="0">
<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
<META HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
</head>
<body class="main" bgcolor="#ffffff" topmargin=0 oncontextmenu="javascript:return false;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td class="sp_10px_row"></td>
			</tr>
		</table>
<table style = " background-color: #ffffff;" cols="2" width="800" height="20" border="0" borderColorDark="black" cellPadding="0" cellSpacing="0" borderColor="black"  >
      <tr>
        <td width="40"><img src="C:/Perl64/bin/OpenStaReport/Template/PageHeaderBullet_trans.gif" alt="" WIDTH="40" HEIGHT="34"></td>
        <td class="header_page">&nbsp;Analysis Summary</td>
        <td class="header_timerange">Duration: $id in Seconds</td>
      </tr>
</table> 
<table style = "margin-left: 30;" height="20" summary="Analysis summary table"  >
	<br>
      <tr height="5" >
        <td class="text_em">Start Time:</td>
        <td headers="LraScenarioName" class="VerBl8">$st</td>
      </tr>
      <tr>
        <td class="text_em">End Time:</td>
        <td headers="LraResultsInSession" class="VerBl8">$et</td>
      </tr>
      <tr>
        <td class="text_em">Date:</td>
        <td headers="LraDuration" class="VerBl8">$datevalue</td>
      </tr>	  
</table> 
  <br>
  
  <table style = "margin-left: 17; background-color: #A9B2C5;" cols="1" width="750" height="22" border="0" cellPadding="0" cellSpacing="0"  >
      <tr>
        <td class="Verdana2Bold">&nbsp; Statistics Summary&nbsp;</td>
      </tr>
</table> 
<table style = "margin-left: 30;" height="20" summary="Transaction summary table"  >
	<br>
      <tr height="5" >
        <td class="text_em">Number of Threads (users):</td>
        <td headers="LraScenarioName" class="VerBl8">$tmp_threads[-1]</td>
      </tr>
               
       <tr><td class="text_em">Total Request:</td><td headers="LraDuration" class="VerBl8">$TR</td></tr>
       <tr><td class="text_em">Http request:</td><td headers="LraDuration" class="VerBl8">$TH  ($THP%)</td></tr>
       <tr><td class="text_em">jmeter Error :</td><td headers="LraDuration" class="VerBl8">$TE  ($TEP%)</td></tr>
	            
       </table> 
	   	
	   <br>
	     <table style = "margin-left: 17; background-color: #A9B2C5;" cols="1" width="750" height="22" border="0" cellPadding="0" cellSpacing="0"  >
      <tr>
        <td class="Verdana2Bold">&nbsp; Response Time Summary&nbsp;</td>
      </tr>
</table>
	   <table style = "margin-left: 30;" height="20" summary="Response Time summary table"  >
	<br>
        <tr><td class="text_em">Minimum Response Time:</td><td headers="LraDuration" class="VerBl8">$minHttpReq</td></tr>
        <tr><td class="text_em">Maximum Response Time:</td><td headers="LraDuration" class="VerBl8">$maxHttpReq</td></tr>
        <tr><td class="text_em">Average Response Time:</td><td headers="LraDuration" class="VerBl8">$RS  (Total Req./Elapsed time)</td></tr>
	</table> 
<br>
 <table style = "margin-left: 17; background-color: #A9B2C5;" cols="1" width="750" height="22" border="0" cellPadding="0" cellSpacing="0"  >
      <tr>
        <td class="Verdana2Bold">&nbsp; Transaction Summary&nbsp;</td>
      </tr>
</table> 
     
<br>
<table style = "margin-left: 17; background-color: ffffff;" width="750" border="0" cellPadding="0" cellSpacing="0" summary="Transactions statistics summary table"  >
<tr bgcolor="ffffff">
        <td id="LraTransaction Name" class="table_header" vAlign="top" width="150"><span class="Verdana2">Transaction Name</span></td>
        <td id="LraAverage" class="table_header" vAlign="top" width="150"><span class="Verdana2">Maximum</span></td>
        <td id="LraMaximum" class="table_header" vAlign="top" width="150"><span class="Verdana2">Minimum</span></td>
        <td id="LraStd. Deviation" class="table_header" vAlign="top" width="150"><span class="Verdana2">Average</span></td>
        <td id="Lra90 Percent" class="table_header" vAlign="top" width="150"><span class="Verdana2">Number of Samplers</span></td>
      </tr>
	   
START
$DATA = "C:/Perl64/bin/JmeterReports/Results.txt";
open(DATA) or die("Could not open log file.");
while (<DATA>) {
    chomp;
	
	my($label,$itimeStamp,$datevalue,$timevalue,$iduration,$durationv,$elapsed,$responseCode,$threadName,$dataType,$success,$bytes,$grpThreads,$allThreads,$URL,$Latency,$IdleTime,$responseMessage,$responseFailed) = split /,/;
		               
             push @{ $data{$label} }, $elapsed;					 # store values as HoA elapsed time   $jmeter{$responseCode}++;
					push @{ $code{$responseMessage} }, $responseCode;
				 #push @{ $data{$label} }, $IdleTime;		
		
	}
#print scalar(@success);
for my $label (sort keys %data) {

   #print "<tr class=\"tabledata_lightrow\"><td headers=\"LraTransaction Name\"><b>$label</b></td>" . summarise($data{$label});
	print OUTR "<tr class=\"tabledata_lightrow\"><td headers=\"LraTransaction Name\"><b>$label-$URL</b></td>". summarise($data{$label});
	


	}
sub summarise{
	my $arr = shift;

	return "<td headers=\"LraAverage\">        <span class=\"VerBl8\">".(sprintf "%.3f",max( @$arr ))."</td>"
		. 	"<td headers=\"LraAverage\">        <span class=\"VerBl8\">".(sprintf "%.3f",min( @$arr ))."</td>"
			#. sum( @$arr ) 
				.	"<td headers=\"LraAverage\">        <span class=\"VerBl8\">".(sprintf "%.3f",(sum(@$arr)/scalar@$arr))."</td>"
					.	"<td headers=\"LraAverage\">        <span class=\"VerBl8\">".scalar@$arr."</td>"
						. "\n";
}
  


 



print OUTR <<START;
<td class="tabledata_end" headers="LraTransaction Name" colspan="9"><img src="./Analysis Summary Report_files/dot_trans.gif" alt="" height="1" width="1" border="0"></td>
      </tr>
</tbody></table> 
  <br>
<table style="margin-left: 17; background-color: #A9B2C5;" cols="1" width="750" height="22" border="0" cellpadding="0" cellspacing="0">
      <tbody><tr>

        <td class="Verdana2Bold">HTTP Responses Summary</td>
      </tr>
</tbody></table> 
  <br>

<a name="1"></a>
<table style="margin-left: 17; background-color: ffffff;" width="750" border="0" cellpadding="0" cellspacing="0" summary="HTTP responses summary table">

      <tbody><tr bgcolor="330066">
        <td id="LraHTTP Responses" class="table_header" valign="top" width="150"><span class="Verdana2">HTTP Responses</span></td>
        <td id="LraTotal" class="table_header" valign="top" width="150">
<a name="HTTPTotal"></a>
<span class="Verdana2">Total</span></td>
        <td id="LraPer second" class="table_header" valign="top" width="150"><span class="Verdana2">Percentage</span></td>
      </tr>
      <tr class="tabledata_lightrow">
START
for my $responseMessage (sort keys %code) 
	
	{

   print OUTR "<tr class=\"tabledata_lightrow\"><td headers=\"LraTransaction Name\"><b>http_ $responseMessage</b></td>".codesummarise($code{$responseMessage});
   
   $TE = codesummarise($code{$responseMessage});
		
	}
sub codesummarise{
	my $arr = shift;

	return 		"<td headers=\"LraAverage\"><span class=\"VerBl8\">". scalar@$arr . "</td>"
				."<td headers=\"LraAverage\"><span class=\"VerBl8\">". scalar@$arr . "</td>";
} 
	  
print OUTR <<START;	  
</tr>
      <tr>
<td class="tabledata_end" headers="LraTransaction Name" colspan="9"><img src="./Analysis Summary Report_files/dot_trans.gif" alt="" height="1" width="1" border="0"></td>
      </tr>

</tbody></table> 
  <br>
<table style="margin-left: 17;" width="750" height="20" summary="Filters">
			<tbody><tr>
				<td class="sp_5px_row"></td>
			</tr>
			<tr>
				<td class="sp_h_line"><img src="C:/Perl64/bin/OpenStaReport/Template/dot_trans.gif" alt="" height="1" width="1" border="0"></td>
			</tr>
			<tr>
				<td class="sp_5px_row"></td>
			</tr>
			<tr>
				<td>
					<div class="pane_full">
						<table border="0" cellspacing="0" cellpadding="0">
							<tbody><tr>
								<td valign="top"><font class="VerBl8"><strong>Filters:&nbsp;</strong></font><font class="VerBl8">(Include Think Time)<br>
									</font></td>
							</tr>
			<tr>
				<td class="sp_5px_row"></td>
			</tr>
						</tbody></table>
					</div>
				</td>
			</tr>
			<tr>
				<td class="sp_h_line"><img src="C:/Perl64/bin/OpenStaReport/Template/dot_trans.gif" alt="" height="1" width="1" border="0"></td>
			</tr>
			<tr>
				<td class="sp_5px_row"></td>
			</tr>
</tbody></table>
<br>
</body></html>
START



