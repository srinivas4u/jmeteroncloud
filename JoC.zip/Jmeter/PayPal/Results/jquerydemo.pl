#!"C:\xampp\perl\bin\perl.exe"


use CGI qw/:standard/;
use File::Basename;
use Date::Parse;
use List::Util qw{sum min max};
use JSON;
use JQuery::Demo ;
use JQuery;
use JQuery::Accordion;
use JQuery::CSS;

require Exporter;
$cgi = new CGI;

print header,start_html($dirpath);
	
print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"';
print '    "http://www.w3.org/TR/html4/loose.dtd">';
print '<html>';
print '<head>';
print '<meta name="author" content="Srinviasan Palanimuthu">';
print '<link href="xampp.css" rel="stylesheet" type="text/css">';
print '<title>Jmeter on Perl V.0.01 Book (JoC)</title>';
print '</head>';

print '<body>';

print "<br><h1>Jmeter on Perl V.0.01 Book (JoC)</h1>";

print "<p>Jmeter Internal Framework</p>"; 
print "<h1>Analysis Summary Report ";

print  <<START;

<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("button").click(function(){
    $("#div1").addClass("important blue");
  });
});
</script>
<style>
.important
{
font-weight:bold;
font-size:xx-large;
}
.blue
{
color:blue;
}
</style>
</head>
<body>

<div id="div1">This is some text.</div>
<div id="div2">This is some text.</div>
<br>
<button>Add classes to first div element</button>

</body>
</html>
START
