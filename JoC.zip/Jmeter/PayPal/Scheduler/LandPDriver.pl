#!"C:\xampp\perl\bin\perl.exe"

###############################################################################
#                                                                             #
#                            Internal Unauth                                  #
###############################################################################

my $filename = 'C:\Jmeter\bin\PayPal\Config\PayPalIdC.txt';
require "$filename";
	
#$users=sprintf("%d",($rampup/$interval_amend));
#$totalfaults = sprintf("%d",$users*$iterationcount);


        print "\n********************************************************************************";
        print "Running Threadgroup : $count \t No.of Threads : $users \n";
        print "********************************************************************************";
			
        system (''.$Jmeterconfig.' -n -t "'.$Scriptconfig."InternalUnauth_10062014 v1.jmx".'" -Jgroup1.threads='.$users.' -Jgroup1.ramp='.$rampup.'');
        sleep($pacing);
        #system (''.$Jmeterconfig.' -n -t "'.$Scriptconfig."TC_WBC_Amend_001.jmx".'" -Jgroup1.threads='.$users1.' -Jgroup1.ramp='.$rampup1.'');
        #sleep($pacing1);
        #system ('perl "WBC_Amend_DBQ.pl"');
        #sleep($pacing2);
        #system (''.$Jmeterconfig.' -n -t "'.$Scriptconfig."TC_WBC_Amend_Part2_001.jmx".'" -Jgroup1.threads='.$users.' -Jgroup1.ramp='.$rampup2.'');
        #print "\n Thread $count completed, will start the next thread after the breathing time $pacing2 seconds\n";
        #sleep($pacing3);
        #system (''.$Jmeterconfig.' -n -t "'.$Scriptconfig."TC_WBC_Amend_Part3_001.jmx".'" -Jgroup1.threads='.$users.' -Jgroup1.ramp='.$rampup3.'');
        #print "\n Thread $count completed, will start the next thread after the breathing time $pacing3 seconds\n";
        
 print "-----------------------------------------------------------\n";
 print "\tHours Ran\tNo.of faults posted\n";
 print "\t$iterationcount\t\t$totalfaults \n";
 print "-----------------------------------------------------------\n";