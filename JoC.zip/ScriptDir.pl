#!"C:\xampp\perl\bin\perl.exe"

use CGI qw/:standard/;
	$cgi = new CGI;
use File::Basename;
    ## Defining variables:
    ## $dirpath retrieve its value from the input called "path".
    ## @FolderContent, @Folders, @Files are array variables to be used later on.
    $dirpath=param('path') if param('path');
    use vars qw/@FolderContent, @Folders, @Files/;

    ## Change current path/folder to $dirpath.
    chdir $dirpath;
    ## Open folder, preparing it for reading.
    unless (opendir DIR,'./Jmeter/PayPal/Scripts') { print "Cannot open directory $dirpath: $!\n"; exit; }
    	## Collect all objects in the folder into an array variable.
    	## Also sort them lexically.
    	@FolderContent = sort readdir DIR;
    closedir DIR;
    
    ## Go through each objects collected.
    foreach $FolderContent(@FolderContent) {
    	## If this object is a folder...
    	if (-d $FolderContent) {
    		## Put it in the @Folders array variable.
    		push(@Folders, $FolderContent);
    	## If it is not a folder (so it is a file).
    	} else {
    		## Put it in the @Files array variable.
    		push(@Files, $FolderContent);
    	}	
    }
	


    
    ## Print header and HTML title (to be viewable in browser).
    print header,start_html($dirpath);
	
print '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"';
print '    "http://www.w3.org/TR/html4/loose.dtd">';
print '<html>';
print '<head>';
print '<meta name="author" content="Srinviasan Palanimuthu">';
print '<link href="xampp.css" rel="stylesheet" type="text/css">';
print '<title>Jmeter on Perl V.0.01 (JoC)</title>';
print '</head>';

print '<body>';

print "<br><h1>Jmeter on Perl V.0.01 (JoC)</h1>";

print "<p>Jmeter Internal Framework</p>"; 
print "<br><h1>";
for $key ( $cgi->param() ) {
   print $project = $input{$key} = $cgi->param($key);
   
}
print "</h1>";
print "<p>-> List of Scripts</p>"; 
	 

    ## Go through each Folders Objects.
    # foreach $Folders(@Folders) {
    	# ## Print out the folders first.
    	# print "$Folders/<br>\n";
    # }
    ## Then go through each Files Objects.
    foreach $Files(@Files) {
  		
	print "<div class='small'>$date</div>";
    print "<table border='0' cellpadding='4' cellspacing='1'>";
    print "<tr><td class='h'>";
    print "<img src='img/blank.gif' alt='' width='450' height='1'><br>";
    print "$i: <a href=ScriptDir.pl>$Files</a> <br>\n";
    print "</td><td class=h>";
    print "<img src='img/blank.gif' alt='' width='450' height='1'><br>";
    print "Description";
    print "</td></tr>";
    print "<tr><td class='d' colspan='2'>";
	print "</td></tr>";
    print "</table>";
    print "<br>";
	$i++;
	    
			}
	
	
    
    
		
		
print "</body>";
print "</html>";